<?php

error_reporting(0);

ini_set("upload_max_filesize", "255M");
ini_set("post_max_size", "256M");

$config["main"]["mysql_server"] = "localhost";
$config["main"]["mysql_user"] = "root";
$config["main"]["mysql_password"] = "";
$config["main"]["mysql_dbname"] = "oski";

$config["main"]["LogsFolder"] = "Logs";

?>